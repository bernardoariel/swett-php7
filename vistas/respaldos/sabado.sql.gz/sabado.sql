CREATE DATABASE IF NOT EXISTS ``;

USE ``;

SET foreign_key_checks = 0;

SET foreign_key_checks = 1;
